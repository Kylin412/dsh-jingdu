# Changelog

## 0.4.1 (2026-11-14)

- 提示音从“自动播报开始前”改为“自动播报自然结束后”播放，避免和 DSH 自带的完成提示音重复。
- 设置项文案改为「播报结束后播放提示音」；手动停止朗读不会播放收尾音。
- 其他功能与 0.4.0 一致。

## 0.4.0 (2026-11-14)

首个公开版本：仓库与包名统一为 `dsh-jingdu`。

- GitHub 仓库、npm 包名、bundle id、客户端模块 id 与 cordis patch id 统一为 `dsh-jingdu`；显示名保持「鲸读」。
- `package.json` 补充 `repository` / `homepage` / `bugs` / `keywords` / `engines` 与 `dsh.manifestVersion`，移除 `private`。
- README 更新公开安装方式（`dsh plugin --profile web add`、源码、`plugin_manager`）、旧版升级说明、MIT 许可证与打包说明。
- 为兼容升级，内部凭据记录 `dsh-deepseek-tts/api-key`、localStorage 键、IndexedDB 缓存库与 `/api/dsh-tts/*` 路由保持不变。
- 功能与 0.4.0-beta.8 一致。

## 0.4.0-beta.8 (2026-11-14)

预发布：显示名改为「鲸读」。

- 侧栏、设置页、README 显示名统一为「鲸读」，副标题「把回复读给你听」。
- 英文显示名改为「Jingdu」。
- 内部包名、bundle id、路由、凭据记录、缓存 key 均保持不变，升级不需要迁移。
- 功能与 0.4.0-beta.7 一致。

## 0.4.0-beta.7 (2026-11-14)

预发布：补充许可证。

- 新增 MIT License 与 `LICENSE` 文件。
- `package.json` 声明 `"license": "MIT"`，发布包包含 `LICENSE`。

## 0.4.0-beta.6 (2026-11-14)

预发布：修复自动播报不出声，补充测试报告。

- 修复 `AutoPlayTail`：turnTail 组件卸载时不再把正在进行的自动播报标记为已取消；此前只响提示音、不执行 `autoSpeak`。
- 新增 `TEST-REPORT.md`：手动朗读、流式播放、自动播报、试听、缓存、Key 灯的时间轴与消耗估算。
- 功能与 0.4.0-beta.5 一致。

## 0.4.0-beta.5 (2026-11-14)

预发布：设置面板二次精简。

- 去掉 API Key / soul.md 卡片的说明文字与文件完整路径，说明改为悬停提示。
- 按钮精简为「保存 / 清除 / 试听」「保存 / 重载」「清理」；下拉精简为「总结（推荐）/ 全文」。
- 开关文案精简为「启用人设」「任务完成后自动播报」「播报前播放提示音」。
- 声线标签去掉「默认」，人设示例缩短。
- 功能与 0.4.0-beta.4 一致。

## 0.4.0-beta.4 (2026-11-14)

预发布：Key 说明文案修正。

- 设置面板 API Key 说明从「保存后同 DSH 共用」改为「只存入插件自己的凭据，不影响 DSH 本体」。
- 首次填写 Key 的提示同步说明只写入插件凭据记录。
- 功能与 0.4.0-beta.3 一致。

## 0.4.0-beta.3 (2026-11-14)

预发布：Key 状态灯与 Key 隔离。

- 「API Key」标题旁新增状态圆点：绿色已配置、红色未配置、琥珀色检查中。
- Key 改为存储在插件私有凭据记录 `dsh-deepseek-tts/api-key`，不再写入/读取共享的 `DEEPSEEK_API_KEY`，不会影响 DSH 本体模型调用。
- 旧版本写入的共享 Key 会在首次使用该 Key 时自动迁移，并从共享 refs 移除；支持环境变量 `DSH_TTS_API_KEY` 作为无界面环境的 Key 来源。
- 功能与 0.4.0-beta.2 一致。

## 0.4.0-beta.2 (2026-11-14)

预发布：设置面板精简。

- 左侧栏「DeepSeek 朗读」页面去掉顶部长介绍、各卡片说明和底部分发说明，仅保留字段与必要提示。
- 保存 Key / 保存 soul.md / 清缓存等操作后的状态文案缩短。
- 功能与 0.4.0-beta.1 一致。

## 0.4.0-beta.1 (2026-11-14)

预发布：代码结构优化，功能与 0.3.4 对齐。

- Host 拆分为 `lib/config.js`、`lib/http.js`、`lib/credentials.js`、`lib/soul.js`、`lib/summary.js` 与 `lib/routes/{speak,summarize,soul,key}.js`；`index.js` 只负责注册路由。
- 路由 path / methods / 错误码 / 返回体保持不变。
- `package.json` 的 `files` 纳入 `lib/**/*.js` 与 `CHANGELOG.md`；版本改为 `0.4.0-beta.1`。
- 新增 `npm pack` 预发布产物：`dist/dsh-deepseek-tts-0.4.0-beta.1.tgz`。
- Client（`client.js`）暂未拆分，行为与 0.3.4 相同。

## 0.3.4

- 人设优先级修正：`soul.md` 为最高优先级；设置页「人设 / 语气」只在冲突时让位。总结缓存版本升到 3。
- 新增「启用人设」开关之前的 0.3.x 已包含：流式 TTS、soul.md、自动播报、语音缓存、侧栏入口、总结/全文开关。

## 0.3.2

- 人设启用、自动播报、完成提示音改为滑动开关，样式与 DSH 设置页一致。

## 0.3.1

- 新增「启用人设」开关；关闭后 soul.md 与「人设 / 语气」不进入总结 prompt。

## 0.3.0

- 流式 TTS（WebSocket PCM，首包即播）、soul.md 人设编辑、总结/全文、自动播报、语音缓存。

## 0.2.0

- 侧栏入口、总结模式、自动播报、图标风格、语音缓存。

## 0.1.0

- 首个可用版本：助手回复上的朗读按钮、总结/全文、Key 设置。
